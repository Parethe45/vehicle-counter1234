largura_min = 80  # Largura minima do retangulo
altura_min = 80  # Altura minima do retangulo
offset = 6  # Erro permitido entre pixel
pos_linha = 550  # Posição da linha de contagem
delay = 60  # FPS do vídeo
detec = []