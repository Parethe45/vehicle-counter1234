# Vehicle Counter
Contador de veículos escrito em Python e OpenCV.
<br><br>
Você vai precisar:
- OpenCV `pip install opencv-python`
- Numpy `pip install numpy`
- Time
- Contrib `pip install opencv-contrib-python`
<br><br>
Confira a explicação do código no **[vídeo](https://youtu.be/25ERpsQcsrY)**.
<p>
    <img align="center" src="https://user-images.githubusercontent.com/49538805/81319198-b3bfa780-9065-11ea-84ba-2d296108ce89.png">
</p>


-------------------------

Gustavo Gino Scotton    |   Engenharia da Computação - UFSC   |   gustavo.gino@outlook.com

